# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "Addon_Creation_Template_v1_0_0",
    "description": "This is a template addon",
    "author": "Enter Your Name Here",
    "version": (1, 0, 0),
    "blender": (2, 80, 0),
    "location": "View3D",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "3D View"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math


###############   INITALIZE VARIABLES
###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        for area in bpy.context.screen.areas:
            area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return int(sn_cast_float_vector(value, size))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
#######   Add-On Preferences Graph
def update_properties_window_context_7E7F1(self, context):
    pass # Script_Change_Properties_Window_Category_Name.py Script Start
    #Script used to update a Panel Name: Particularly the Properties Window Panel


    #Function: Get the class of the Panel and store it in variable cls. Then re-register the class with a different name from a Serpens Property
    #If you want to test and run this script in the Text Editor then Simply use the import bpy and uncomment the print at the bottom as well
    #import bpy


    #Change Name in Single Quotes below to the correct Class Name. You are looking for the class name of your Properties Panel
    cls_prop = getattr(bpy.types, 'SNA_PT_New_Properties_Panel_A95D2')
    if cls_prop.is_registered:
        #print(cls_prop.bl_context)
        if self.properties_window_context.lower() == "any space":
            bpy.utils.unregister_class(cls_prop)
            cls_prop.bl_context = ""
            bpy.utils.register_class(cls_prop)
        else:
            bpy.utils.unregister_class(cls_prop)
            #Change the Property Name below using the Add-on Preferences Property Window Context Name
            cls_prop.bl_context = self.properties_window_context.lower() #If you prefer to use a Scene property: bpy.context.scene.PROPERTY_NAME (replace PROPERTY NAME with your property)
            bpy.utils.register_class(cls_prop)
    # print(cls)
    pass # Script_Change_Properties_Window_Category_Name.py Script End

def update_sn_3d_view_npanel_category_7E7F1(self, context):
    pass # Script_Change_3DView_Category_Name_Template.py Script Start
    #Script used to update a Panel Name: Particularly the 3D View N-Panel but other panels will follow this similar structure


    #Function: Get the class of the Panel and store it in variable cls_n_panel. Then re-register the class with a different name from a Serpens Property
    #If you want to test and run this script in the Text Editor then Simply use the import bpy and uncomment the print at the bottom as well
    #import bpy


    #Change Name in Single Quotes below (SNA_PT_New_Header_Name_0303A) to the correct Class Name. You are looking for the class name of your 3D View N-Panel
    cls_n_panel = getattr(bpy.types, 'SNA_PT_New_Header_Name_0303A')
    if cls_n_panel.is_registered:
        #cls_n_panel.bl_category #You can find out what the category is if you'd like but this is not necessary
        bpy.utils.unregister_class(cls_n_panel)
        #Change the Property Name below using the Add-on Preference Nodes Property
        cls_n_panel.bl_category = self.sn_3d_view_npanel_category #If you prefer to use a Scene property: bpy.context.scene.PROPERTY_NAME (replace PROPERTY NAME with your scene property)
        bpy.utils.register_class(cls_n_panel)
    # print(cls_n_panel)
    pass # Script_Change_3DView_Category_Name_Template.py Script End


#######   Keymap and Pie Menu - On Keypress Graph
addon_keymaps = []


#######   Keymap and Pop-Up Menu - On Keypress Graph
addon_keymaps = []


###############   EVALUATED CODE
#######   Add-On Preferences Graph
class SNA_OT_Toggle_Aggressive_Info_Logs(bpy.types.Operator):
    bl_idname = "sna.toggle_aggressive_info_logs"
    bl_label = "Toggle Aggressive Info Logs"
    bl_description = " "
    bl_options = {"REGISTER", "UNDO"}
    toggle_bool : bpy.props.BoolProperty(name='Toggle Bool',description='',options=set(),default=False)


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            self.toggle_bool = not self.toggle_bool
            pass # Script_Toggle_Aggressive_Info_Log Script Start
            #Script Aggressive Info Log Events
            #Set bpy.app.debug_wm to true for posting many events. 
            #Set to false for normal event behavior.
            bpy.app.debug_wm = self.toggle_bool
            pass # Script_Toggle_Aggressive_Info_Log Script End
            print(r"Aggressive Logging: ", sn_cast_string(self.toggle_bool))
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Toggle Aggressive Info Logs")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Toggle Aggressive Info Logs")
        return self.execute(context)


class SNA_OT_Clear_The_Console(bpy.types.Operator):
    bl_idname = "sna.clear_the_console"
    bl_label = "Clear The Console"
    bl_description = " "
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass # Script_Clear_Console.py Script Start
            #Script used to clear the Blender Console found at Window -> Toggle System Console
            from os import system
            cls_clrcnsl = lambda: system('cls')
            cls_clrcnsl() #this function call will clear the console
            pass # Script_Clear_Console.py Script End
            print(r"Console Cleared.")
            repeat_node_8BA2D = 0
            for repeat_node_8BA2D in range(2):
                bpy.ops.wm.console_toggle("INVOKE_DEFAULT",)
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Clear The Console")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Clear The Console")
        return self.execute(context)


class SNA_OT_Reset_3D_View_Npanel_Category(bpy.types.Operator):
    bl_idname = "sna.reset_3d_view_npanel_category"
    bl_label = "Reset 3D View N-Panel Category"
    bl_description = " "
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            context.preferences.addons[__name__.partition('.')[0]].preferences.sn_3d_view_npanel_category = r"My New Category"
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Reset 3D View N-Panel Category")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Reset 3D View N-Panel Category")
        return self.execute(context)


class SNA_AddonPreferences_7E7F1(bpy.types.AddonPreferences):
    bl_idname = __name__.partition('.')[0]
    general : bpy.props.BoolProperty(name='General',description='General Settings',options=set(),default=True)
    options : bpy.props.BoolProperty(name='Options',description='Add-on Options',options=set(),default=False)
    support : bpy.props.BoolProperty(name='Support',description='Get Support for the Add-on',options=set(),default=False)
    sn_3d_view_npanel_category : bpy.props.StringProperty(name='3D View N-Panel Category',description='',subtype='NONE',options=set(),update=update_sn_3d_view_npanel_category_7E7F1,default='My New Category')
    properties_window_context : bpy.props.EnumProperty(name='Properties Window Context',description='Property Window Context',options=set(),update=update_properties_window_context_7E7F1,items=[('Any Space', 'Any Space', 'Display on all Properties'), ('Render', 'Render', 'Render Properties'), ('Output', 'Output', 'Output Properties'), ('View_Layer', 'View_Layer', 'View Layer Properties'), ('Scene', 'Scene', 'Scene Properties'), ('World', 'World', 'World Properties'), ('Object', 'Object', 'Object Properties'), ('Modifier', 'Modifier', 'Modifier Properties'), ('Particles', 'Particles', 'Particles Properties'), ('Physics', 'Physics', 'Physics Properties'), ('Constraint', 'Constraint', 'Object Constraint Properties'), ('Data', 'Data', 'Object Data Properties'), ('Material', 'Material', 'Material Properties'), ('Texture', 'Texture', 'Texture Properties')])

    def draw(self, context):
        try:
            layout = self.layout
            col = layout.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("sna.addon_preferences__general",text=r"General",emboss=True,depress=context.preferences.addons[__name__.partition('.')[0]].preferences.general,icon_value=92)
            op = row.operator("sna.addon_preferences__options",text=r"Options",emboss=True,depress=context.preferences.addons[__name__.partition('.')[0]].preferences.options,icon_value=23)
            op = row.operator("sna.addon_preferences__support",text=r"Support",emboss=True,depress=context.preferences.addons[__name__.partition('.')[0]].preferences.support,icon_value=1)
            col.separator(factor=4.0)
            if context.preferences.addons[__name__.partition('.')[0]].preferences.general:
                col = col.column(align=True)
                col.enabled = True
                col.alert = False
                col.scale_x = 1.0
                col.scale_y = 1.0
                row = col.row(align=True)
                row.enabled = True
                row.alert = False
                row.scale_x = 1.0
                row.scale_y = 1.0
                row.label(text=r"3D View N-Panel Category:",icon_value=0)
                row.prop(context.preferences.addons[__name__.partition('.')[0]].preferences,"sn_3d_view_npanel_category",icon_value=0,text=r"",emboss=True,)
                if context.preferences.addons[__name__.partition('.')[0]].preferences.sn_3d_view_npanel_category == r"My New Category":
                    pass
                else:
                    op = row.operator("sna.reset_3d_view_npanel_category",text=r"",emboss=True,depress=False,icon_value=715)
                row.separator(factor=1.0)
                row.label(text=r"",icon_value=14)
                row.separator(factor=1.0)
                col.separator(factor=2.0)
                col = col.column(align=True)
                col.enabled = True
                col.alert = False
                col.scale_x = 1.0
                col.scale_y = 1.0
                row = col.row(align=True)
                row.enabled = True
                row.alert = False
                row.scale_x = 1.0
                row.scale_y = 1.0
                row.label(text=r"Properties Panel Category:",icon_value=0)
                row.prop(self,"properties_window_context",icon_value=0,text=r"",emboss=True,expand=False,)
                row.separator(factor=1.0)
                row.label(text=r"",icon_value=14)
                row.separator(factor=1.0)
                col.separator(factor=2.0)
            else:
                pass
            if context.preferences.addons[__name__.partition('.')[0]].preferences.options:
                col = col.column(align=True)
                col.enabled = True
                col.alert = False
                col.scale_x = 1.0
                col.scale_y = 1.0
                row = col.row(align=True)
                row.enabled = True
                row.alert = False
                row.scale_x = 1.0
                row.scale_y = 1.0
                row.label(text=r"Toggle Console:",icon_value=0)
                op = row.operator("wm.console_toggle",text=r"",emboss=True,depress=False,icon_value=121)
                row.separator(factor=1.0)
                col.separator(factor=2.0)
                col = col.column(align=True)
                col.enabled = True
                col.alert = False
                col.scale_x = 1.0
                col.scale_y = 1.0
                row = col.row(align=True)
                row.enabled = True
                row.alert = False
                row.scale_x = 1.0
                row.scale_y = 1.0
                row.label(text=r"Clear Console:",icon_value=0)
                op = row.operator("sna.clear_the_console",text=r"",emboss=True,depress=False,icon_value=49)
                row.separator(factor=1.0)
                col.separator(factor=2.0)
                col = col.column(align=True)
                col.enabled = True
                col.alert = False
                col.scale_x = 1.0
                col.scale_y = 1.0
                row = col.row(align=True)
                row.enabled = True
                row.alert = False
                row.scale_x = 1.0
                row.scale_y = 1.0
                row.label(text=r"Clear Serpens Print:",icon_value=0)
                op = row.operator("sn.remove_print",text=r"",emboss=True,depress=False,icon_value=21)
                row.separator(factor=1.0)
                col.separator(factor=2.0)
                col = col.column(align=True)
                col.enabled = True
                col.alert = False
                col.scale_x = 1.0
                col.scale_y = 1.0
                row = col.row(align=True)
                row.enabled = True
                row.alert = False
                row.scale_x = 1.0
                row.scale_y = 1.0
                row.label(text=r"Toggle Aggressive Logging:",icon_value=0)
                op = row.operator("sna.toggle_aggressive_info_logs",text=r"",emboss=True,depress=False,icon_value=698)
                row.separator(factor=1.0)
                col.separator(factor=2.0)
            else:
                pass
            if context.preferences.addons[__name__.partition('.')[0]].preferences.support:
                col = col.column(align=True)
                col.enabled = True
                col.alert = False
                col.scale_x = 1.0
                col.scale_y = 1.0
                row = col.row(align=True)
                row.enabled = True
                row.alert = False
                row.scale_x = 1.0
                row.scale_y = 1.0
                row.label(text=r"",icon_value=0)
                op = row.operator("wm.url_open",text=r"Discord",emboss=True,depress=False,icon_value=158)
                op.url = r"https://discord.com/channels/710912354535079937/784456758990864444"
                op = row.operator("wm.url_open",text=r"Need An Invite?",emboss=True,depress=False,icon_value=0)
                op.url = r"https://discord.com/invite/NK6kyae"
                row.label(text=r"",icon_value=0)
                row.separator(factor=1.0)
                col.separator(factor=2.0)
                col = col.column(align=True)
                col.enabled = True
                col.alert = False
                col.scale_x = 1.0
                col.scale_y = 1.0
                row = col.row(align=True)
                row.enabled = True
                row.alert = False
                row.scale_x = 1.0
                row.scale_y = 1.0
                row.label(text=r"",icon_value=0)
                op = row.operator("wm.url_open",text=r"Blender Market",emboss=True,depress=False,icon_value=158)
                op.url = r"https://blendermarket.com/"
                row.label(text=r"",icon_value=0)
                row.separator(factor=1.0)
                col.separator(factor=2.0)
                col = col.column(align=True)
                col.enabled = True
                col.alert = False
                col.scale_x = 1.0
                col.scale_y = 1.0
                row = col.row(align=True)
                row.enabled = True
                row.alert = False
                row.scale_x = 1.0
                row.scale_y = 1.0
                row.label(text=r"",icon_value=0)
                op = row.operator("wm.url_open",text=r"Gumroad",emboss=True,depress=False,icon_value=158)
                op.url = r"https://gumroad.com/"
                row.label(text=r"",icon_value=0)
                row.separator(factor=1.0)
                col.separator(factor=2.0)
                col = col.column(align=True)
                col.enabled = True
                col.alert = False
                col.scale_x = 1.0
                col.scale_y = 1.0
                row = col.row(align=True)
                row.enabled = True
                row.alert = False
                row.scale_x = 1.0
                row.scale_y = 1.0
                row.label(text=r"",icon_value=0)
                op = row.operator("wm.url_open",text=r"Leave a Review",emboss=True,depress=False,icon_value=158)
                op.url = r"https://gumroad.com/"
                row.label(text=r"",icon_value=0)
                row.separator(factor=1.0)
                col.separator(factor=2.0)
            else:
                pass
            col.separator(factor=6.0)
            col = col.column(align=False)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            col.label(text=r"CHANGELOG:",icon_value=0)
            col.separator(factor=1.0)
            col.label(text=r"Version 1.0.0",icon_value=0)
            row = col.row(align=False)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.label(text=r"Initiall Release",icon_value=644)
            col.separator(factor=1.0)
            col.label(text=r"This template made by Shawn Blanch (blanchsb)",icon_value=0)
        except Exception as exc:
            print(str(exc) + " | Error in  addon preferences")


class SNA_OT_Addon_Preferences__General(bpy.types.Operator):
    bl_idname = "sna.addon_preferences__general"
    bl_label = "Add-on Preferences - General"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            context.preferences.addons[__name__.partition('.')[0]].preferences.options = False
            context.preferences.addons[__name__.partition('.')[0]].preferences.support = False
            context.preferences.addons[__name__.partition('.')[0]].preferences.general = True
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Add-on Preferences - General")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Add-on Preferences - General")
        return self.execute(context)


class SNA_OT_Addon_Preferences__Options(bpy.types.Operator):
    bl_idname = "sna.addon_preferences__options"
    bl_label = "Add-on Preferences - Options"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            context.preferences.addons[__name__.partition('.')[0]].preferences.general = False
            context.preferences.addons[__name__.partition('.')[0]].preferences.support = False
            context.preferences.addons[__name__.partition('.')[0]].preferences.options = True
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Add-on Preferences - Options")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Add-on Preferences - Options")
        return self.execute(context)


class SNA_OT_Addon_Preferences__Support(bpy.types.Operator):
    bl_idname = "sna.addon_preferences__support"
    bl_label = "Add-on Preferences - Support"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            context.preferences.addons[__name__.partition('.')[0]].preferences.general = False
            context.preferences.addons[__name__.partition('.')[0]].preferences.options = False
            context.preferences.addons[__name__.partition('.')[0]].preferences.support = True
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Add-on Preferences - Support")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Add-on Preferences - Support")
        return self.execute(context)


#######   Keymap and Pie Menu - On Keypress Graph
class SNA_MT_Template_Pie_Menu_9B165(bpy.types.Menu):
    bl_idname = "SNA_MT_Template_Pie_Menu_9B165"
    bl_label = "Template Pie Menu"


    @classmethod
    def poll(cls, context):
        return True

    def draw(self, context):
        try:
            layout = self.layout
            layout = layout.menu_pie()
            col = layout.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("wm.console_toggle",text=r"  Toggle Console",emboss=True,depress=False,icon_value=121)
            row.separator(factor=1.0)
            col.separator(factor=1.0)
            col = layout.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("sna.clear_the_console",text=r"  Clear Console",emboss=True,depress=False,icon_value=49)
            row.separator(factor=1.0)
            col.separator(factor=1.0)
            col = layout.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("sn.remove_print",text=r"  Clear Serpens Print",emboss=True,depress=False,icon_value=21)
            row.separator(factor=1.0)
            col.separator(factor=1.0)
            col = layout.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("sna.toggle_aggressive_info_logs",text=r"  Toggle Aggressive Logging",emboss=True,depress=False,icon_value=698)
            row.separator(factor=1.0)
            col.separator(factor=2.0)
        except Exception as exc:
            print(str(exc) + " | Error in Template Pie Menu pie menu")

def register_key_09CCF():
    kc = bpy.context.window_manager.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name="Window", space_type="EMPTY")
        kmi = km.keymap_items.new("wm.call_menu_pie",
                                    type= "U",
                                    value= "PRESS",
                                    repeat= False,
                                    ctrl=True,
                                    alt=False,
                                    shift=False)
        kmi.properties.name = "SNA_MT_Template_Pie_Menu_9B165"
        addon_keymaps.append((km, kmi))


#######   Keymap and Pop-Up Menu - On Keypress Graph
class SNA_MT_A_New_PopUp_Menu_2EC9E(bpy.types.Menu):
    bl_idname = "SNA_MT_A_New_PopUp_Menu_2EC9E"
    bl_label = "A New Pop-Up Menu"


    @classmethod
    def poll(cls, context):
        return True

    def draw(self, context):
        try:
            layout = self.layout
            col = layout.column(align=False)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("wm.console_toggle",text=r"",emboss=True,depress=False,icon_value=121)
            row.label(text=r" :Toggle Console",icon_value=0)
            row.separator(factor=1.0)
            col.separator(factor=1.0)
            col = col.column(align=False)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("sna.clear_the_console",text=r"",emboss=True,depress=False,icon_value=49)
            row.label(text=r" :Clear Console",icon_value=0)
            row.separator(factor=1.0)
            col.separator(factor=1.0)
            col = col.column(align=False)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("sn.remove_print",text=r"",emboss=True,depress=False,icon_value=21)
            row.label(text=r" :Clear Serpens Print",icon_value=0)
            row.separator(factor=1.0)
            col.separator(factor=1.0)
            col = col.column(align=False)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("sna.toggle_aggressive_info_logs",text=r"",emboss=True,depress=False,icon_value=698)
            row.label(text=r" :Toggle Aggressive Logging",icon_value=0)
            row.separator(factor=1.0)
            col.separator(factor=2.0)
        except Exception as exc:
            print(str(exc) + " | Error in A New Pop-Up Menu menu")

def register_key_B93DC():
    kc = bpy.context.window_manager.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name="Window", space_type="EMPTY")
        kmi = km.keymap_items.new("wm.call_menu",
                                    type= "U",
                                    value= "PRESS",
                                    repeat= False,
                                    ctrl=False,
                                    alt=True,
                                    shift=False)
        kmi.properties.name = "SNA_MT_A_New_PopUp_Menu_2EC9E"
        addon_keymaps.append((km, kmi))


#######   Panel - 3D Viewport Editor - N-Panel Graph
class SNA_PT_New_Header_Name_0303A(bpy.types.Panel):
    bl_label = "New Header Name"
    bl_idname = "SNA_PT_New_Header_Name_0303A"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'My New Category'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return True

    def draw_header(self, context):
        try:
            layout = self.layout
            layout.label(text=r"",icon_value=24)
        except Exception as exc:
            print(str(exc) + " | Error in New Header Name panel header")

    def draw(self, context):
        try:
            layout = self.layout
            col = layout.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.label(text=r"Toggle Console:",icon_value=0)
            op = row.operator("wm.console_toggle",text=r"",emboss=True,depress=False,icon_value=121)
            row.separator(factor=1.0)
            col.separator(factor=1.0)
            col = col.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.label(text=r"Clear Console:",icon_value=0)
            op = row.operator("sna.clear_the_console",text=r"",emboss=True,depress=False,icon_value=49)
            row.separator(factor=1.0)
            col.separator(factor=1.0)
            col = col.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.label(text=r"Clear Serpens Print:",icon_value=0)
            op = row.operator("sn.remove_print",text=r"",emboss=True,depress=False,icon_value=21)
            row.separator(factor=1.0)
            col.separator(factor=1.0)
            col = col.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.label(text=r"Toggle Aggressive Logging:",icon_value=0)
            op = row.operator("sna.toggle_aggressive_info_logs",text=r"",emboss=True,depress=False,icon_value=698)
            row.separator(factor=1.0)
            col.separator(factor=2.0)
        except Exception as exc:
            print(str(exc) + " | Error in New Header Name panel")


#######   Panel - Properties Window Editor  - Panel Graph
class SNA_PT_New_Properties_Panel_A95D2(bpy.types.Panel):
    bl_label = "New Properties Panel"
    bl_idname = "SNA_PT_New_Properties_Panel_A95D2"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return True

    def draw_header(self, context):
        try:
            layout = self.layout
            layout.label(text=r"",icon_value=24)
        except Exception as exc:
            print(str(exc) + " | Error in New Properties Panel panel header")

    def draw(self, context):
        try:
            layout = self.layout
            col = layout.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.label(text=r"Toggle Console:",icon_value=0)
            op = row.operator("wm.console_toggle",text=r"",emboss=True,depress=False,icon_value=121)
            row.separator(factor=1.0)
            col.separator(factor=2.0)
            col = col.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.label(text=r"Clear Console:",icon_value=0)
            op = row.operator("sna.clear_the_console",text=r"",emboss=True,depress=False,icon_value=49)
            row.separator(factor=1.0)
            col.separator(factor=2.0)
            col = col.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.label(text=r"Clear Serpens Print:",icon_value=0)
            op = row.operator("sn.remove_print",text=r"",emboss=True,depress=False,icon_value=21)
            row.separator(factor=1.0)
            col.separator(factor=2.0)
            col = col.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.label(text=r"Toggle Aggressive Logging:",icon_value=0)
            op = row.operator("sna.toggle_aggressive_info_logs",text=r"",emboss=True,depress=False,icon_value=698)
            row.separator(factor=1.0)
            col.separator(factor=2.0)
        except Exception as exc:
            print(str(exc) + " | Error in New Properties Panel panel")


#######   Menu - 3D Viewport Graph
class SNA_MT_A_New_Menu_A076B(bpy.types.Menu):
    bl_idname = "SNA_MT_A_New_Menu_A076B"
    bl_label = "A New Menu"


    @classmethod
    def poll(cls, context):
        return True

    def draw(self, context):
        try:
            layout = self.layout
            col = layout.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("wm.console_toggle",text=r"",emboss=True,depress=False,icon_value=121)
            row.label(text=r" :   Toggle Console",icon_value=0)
            row.separator(factor=1.0)
            col.separator(factor=1.0)
            col = layout.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("sna.clear_the_console",text=r"",emboss=True,depress=False,icon_value=49)
            row.label(text=r" :   Clear Console",icon_value=0)
            row.separator(factor=1.0)
            col.separator(factor=1.0)
            col = layout.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("sn.remove_print",text=r"",emboss=True,depress=False,icon_value=21)
            row.label(text=r" :   Clear Serpens Print",icon_value=0)
            row.separator(factor=1.0)
            col.separator(factor=1.0)
            col = layout.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=True)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("sna.toggle_aggressive_info_logs",text=r"",emboss=True,depress=False,icon_value=698)
            row.label(text=r" :   Toggle Aggressive Logs",icon_value=0)
            row.separator(factor=1.0)
            col.separator(factor=2.0)
        except Exception as exc:
            print(str(exc) + " | Error in A New Menu menu")

def sn_append_menu_5D270(self,context):
    try:
        layout = self.layout
        layout.menu("SNA_MT_A_New_Menu_A076B",text=r"",icon_value=181)
    except Exception as exc:
        print(str(exc) + " | Error in View3D Mt Editor Menus when adding to menu")


#######   Add To Menu - Info Log - Clear Info Log Graph
class SNA_OT_Clear_The_Info_Log(bpy.types.Operator):
    bl_idname = "sna.clear_the_info_log"
    bl_label = "Clear The Info Log"
    bl_description = " "
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            bpy.ops.info.select_all("INVOKE_DEFAULT",action=sn_cast_enum(r"SELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
            bpy.ops.info.report_delete("INVOKE_DEFAULT",)
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Clear The Info Log")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Clear The Info Log")
        return self.execute(context)

def sn_append_menu_5A355(self,context):
    try:
        layout = self.layout
        row = layout.row(align=True)
        row.enabled = True
        row.alert = False
        row.scale_x = 1.0
        row.scale_y = 1.0
        row.separator(factor=2.0)
        op = row.operator("sna.toggle_aggressive_info_logs",text=r"",emboss=True,depress=False,icon_value=698)
        op = row.operator("sna.clear_the_info_log",text=r"",emboss=True,depress=False,icon_value=21)
        row.separator(factor=2.0)
        op = row.operator("wm.console_toggle",text=r"",emboss=True,depress=False,icon_value=121)
        op = row.operator("sna.clear_the_console",text=r"",emboss=True,depress=False,icon_value=49)
    except Exception as exc:
        print(str(exc) + " | Error in Info Mt Editor Menus when adding to menu")


#######   Add To Menu - Console - Clear Console Graph
def sn_append_menu_0A661(self,context):
    try:
        layout = self.layout
        row = layout.row(align=True)
        row.enabled = True
        row.alert = False
        row.scale_x = 1.0
        row.scale_y = 1.0
        row.separator(factor=2.0)
        op = row.operator("console.clear",text=r"",emboss=True,depress=False,icon_value=21)
        op.scrollback = True
        op.history = True
        row.separator(factor=2.0)
        op = row.operator("wm.console_toggle",text=r"",emboss=True,depress=False,icon_value=121)
        op = row.operator("sna.clear_the_console",text=r"",emboss=True,depress=False,icon_value=49)
    except Exception as exc:
        print(str(exc) + " | Error in Console Mt Editor Menus when adding to menu")


###############   REGISTER ICONS
def sn_register_icons():
    icons = []
    bpy.types.Scene.addon_creation_template_v1_0_0_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.addon_creation_template_v1_0_0_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.addon_creation_template_v1_0_0_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    pass

def sn_unregister_properties():
    pass


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.utils.register_class(SNA_OT_Toggle_Aggressive_Info_Logs)
    bpy.utils.register_class(SNA_OT_Clear_The_Console)
    bpy.utils.register_class(SNA_OT_Reset_3D_View_Npanel_Category)
    bpy.utils.register_class(SNA_AddonPreferences_7E7F1)
    bpy.utils.register_class(SNA_OT_Addon_Preferences__General)
    bpy.utils.register_class(SNA_OT_Addon_Preferences__Options)
    bpy.utils.register_class(SNA_OT_Addon_Preferences__Support)
    bpy.utils.register_class(SNA_MT_Template_Pie_Menu_9B165)
    register_key_09CCF()
    bpy.utils.register_class(SNA_MT_A_New_PopUp_Menu_2EC9E)
    register_key_B93DC()
    bpy.utils.register_class(SNA_PT_New_Header_Name_0303A)
    bpy.utils.register_class(SNA_PT_New_Properties_Panel_A95D2)
    bpy.utils.register_class(SNA_MT_A_New_Menu_A076B)
    bpy.utils.register_class(SNA_OT_Clear_The_Info_Log)
    bpy.types.VIEW3D_MT_editor_menus.append(sn_append_menu_5D270)
    bpy.types.INFO_MT_editor_menus.append(sn_append_menu_5A355)
    bpy.types.CONSOLE_MT_editor_menus.append(sn_append_menu_0A661)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.types.CONSOLE_MT_editor_menus.remove(sn_append_menu_0A661)
    bpy.types.INFO_MT_editor_menus.remove(sn_append_menu_5A355)
    bpy.types.VIEW3D_MT_editor_menus.remove(sn_append_menu_5D270)
    bpy.utils.unregister_class(SNA_OT_Clear_The_Info_Log)
    bpy.utils.unregister_class(SNA_MT_A_New_Menu_A076B)
    bpy.utils.unregister_class(SNA_PT_New_Properties_Panel_A95D2)
    bpy.utils.unregister_class(SNA_PT_New_Header_Name_0303A)
    for km,kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_MT_A_New_PopUp_Menu_2EC9E)
    for km,kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_MT_Template_Pie_Menu_9B165)
    bpy.utils.unregister_class(SNA_OT_Addon_Preferences__Support)
    bpy.utils.unregister_class(SNA_OT_Addon_Preferences__Options)
    bpy.utils.unregister_class(SNA_OT_Addon_Preferences__General)
    bpy.utils.unregister_class(SNA_AddonPreferences_7E7F1)
    bpy.utils.unregister_class(SNA_OT_Reset_3D_View_Npanel_Category)
    bpy.utils.unregister_class(SNA_OT_Clear_The_Console)
    bpy.utils.unregister_class(SNA_OT_Toggle_Aggressive_Info_Logs)